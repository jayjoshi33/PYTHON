from django.urls import path
from . import views
urlpatterns = [
    path('',views.home,name='home'),
    path('form',views.form,name='form'),
    path('form1',views.form1,name='form1'),
    path('formprocess1',views.process1,name='form1'),
    path('formprocess',views.process,name='process'),
    path('form2',views.form2,name='form2'),
    path('formprocess2',views.process2,name='process2'),
    path('form3',views.form3,name='form3'),
    path('formprocess3',views.process3,name='process3')
]

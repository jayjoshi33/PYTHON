from django.http.response import HttpResponse
from django.shortcuts import render

# Create your views here.
def home(request):
    return render(request,"home.html")
def form(request):
    return render(request,"form.html")  
def form1(request):
    return render(request,"form1.html") 
def form2(request):
    return render(request,"form2.html")  
def form3(request):
    return render(request,'form3.html')           
def process(request):
    a=int(request.GET['t1'])
    b=int(request.GET['t2'])
    c=a+b
    return render(request,'add.html',{'sum':c,'a':a,'b':b})

def process1(request):
    a=int(request.GET['t1'])
    b=int(request.GET['t2'])
    c=a-b
    return render(request,'sub.html',{'sum':c,'a':a,'b':b})
def process2(request):
    a=int(request.GET['t1'])
    b=int(request.GET['t2'])
    c=a*b
    return render(request,'mul.html',{'sum':c,'a':a,'b':b})
def process3(request):
    a=int(request.GET['t1'])
    b=int(request.GET['t2'])
    c=a/b
    return render(request,'div.html',{'sum':c,'a':a,'b':b})

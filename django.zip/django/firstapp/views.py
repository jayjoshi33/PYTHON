
from django.shortcuts import get_list_or_404, render
from django.http import HttpResponse

from django.views.generic import ListView
from .models import Student
# Create your views here.
def homepage(request):
    t="Welcome to django"
    return render(request,'home.html')
def about(request):
    return render(request,'about.html')    
def contact(request):
    return render(request,'contact.html')    
def form(request):
    return render(request,'form.html')
def process(request):
    print("Welcome")
    a=str(request.POST['name'])
    b=str(request.POST['user'])
    c=str(request.POST['rad'])
    d=str(request.POST['hob'])

    return render(request,"ans.html",{'a':a,'b':b,'c':c,'d':d})    

class studentlist(ListView):
    model=Student
    template_name='slist.html'

def hello(request):
    return HttpResponse("Hello World")    
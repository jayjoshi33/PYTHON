from django.db import models

# Create your models here.
class Student(models.Model):
    First_name=models.CharField(max_length=30)
    l_name=models.CharField(max_length=30)
    gender=models.BooleanField(default=False)
    fees=models.IntegerField()

    def __str__(self):
        return self.First_name

class Employee(models.Model):
    Name=models.CharField(max_length=25)
    Number=models.IntegerField()
    Salary=models.IntegerField()

    def __str__(self):
        return self.Name
    